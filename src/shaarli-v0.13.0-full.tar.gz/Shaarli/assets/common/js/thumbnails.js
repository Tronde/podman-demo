import Blazy from 'blazy';

(() => {
  // Suppress ESLint error because that's how bLazy works
  /* eslint-disable no-new */
  new Blazy();
})();
